from flask import Flask,render_template,request
import requests
import json


app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")

@app.route("/title/",methods=["POST","GET"])
def title():
    
    """
        This function is used to return movie data
    """
    
    movie = request.form.get("title")
    url = f"http://www.omdbapi.com/?t={movie}&apikey=e22bdd41"
    page = requests.get(url)
    data = json.loads(page.text)
    content = ['Title','Actors','Year','Genre','Released','Director','Plot','Language','imdbRating']
    d = {}
    for i in content:
        d[i]=data[i]
    poster = data['Poster']
    return render_template("movie.html",data=d,poster=poster)
    


app.run(host="localhost",port=80,debug=True)
